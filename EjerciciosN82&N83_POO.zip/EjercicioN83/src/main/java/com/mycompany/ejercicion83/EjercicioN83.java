/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicion83;

/**
 *
 * @author crisc
 */
public class EjercicioN83 {

    public static void main(String[] args) {
        VentanaPrincipal miVentanaPrincipal; 
        miVentanaPrincipal= new VentanaPrincipal();
        
        miVentanaPrincipal.setVisible(true);

        miVentanaPrincipal.setResizable(false);
        }
    }
