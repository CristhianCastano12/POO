/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicion82notas;

/**
 *
 * @author crisc
 */
public class EjercicioN82Notas {
    public static void main(String[] args) {
        VentanaPrincipal formulario = new VentanaPrincipal ();
        formulario.setResizable(false);
        formulario.setVisible(true);
    }
}
